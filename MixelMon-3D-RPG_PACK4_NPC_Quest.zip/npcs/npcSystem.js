import { showDialogue } from './dialogueUI.js';
import { keys } from '../engine/input.js';
import { loadNPCData } from './npcUtils.js';

let npcList = [];
let playerRef = null;

export function initNPCs(scene, player){
    playerRef = player;
    loadNPCData().then(data=>{
        data.npcs.forEach(n=>{
            let npc = createNPC(n.color);
            npc.position.set(n.x, n.y, n.z);
            npc.dialogue = n.dialogue;
            npc.isTrainer = n.isTrainer;
            npcList.push(npc);
            scene.add(npc);
        });
    });
}

function createNPC(color = 0xffffff){
    let group = new THREE.Group();
    let body = new THREE.Mesh(
        new THREE.BoxGeometry(1,2,1),
        new THREE.MeshStandardMaterial({color})
    );
    group.add(body);

    let head = new THREE.Mesh(
        new THREE.BoxGeometry(1,1,1),
        new THREE.MeshStandardMaterial({color: color + 0x111111})
    );
    head.position.y = 1.5;
    group.add(head);

    group.tick = function(t){
        group.position.y = Math.sin(t*2)*0.05;
    };

    return group;
}

export function updateNPCs(t, scene){
    npcList.forEach(npc=>{
        npc.tick(t);

        let dist = playerRef.position.distanceTo(npc.position);

        if(dist < 2 && keys['e']){
            if(npc.isTrainer){
                triggerTrainerBattle(npc);
            } else {
                showDialogue(npc.dialogue);
            }
        }
    });
}

function triggerTrainerBattle(npc){
    console.log("!! Trainer Battle Triggered !!");

    let glitch = document.createElement("div");
    glitch.id = "glitchEffect";
    document.body.appendChild(glitch);

    setTimeout(()=>{
        glitch.remove();
        import('../battle/battle.js').then(b=>b.startBattle(1,2));
    }, 800);
}
