export async function loadNPCData(){
    let r = await fetch('./npcs/npcs.json');
    return await r.json();
}
