export let quests = {
    intro:{
        id:"intro",
        text:["Welcome to MixelMon.","Your journey begins now."],
        completed:false,
        reward:{coins:10}
    }
};
