export function showDialogue(lines){
    let box = document.getElementById("dialogueBox");
    let text = document.getElementById("dialogueText");

    box.classList.remove("hidden");
    let queue = [...lines];

    function next(){
        if(queue.length === 0){
            box.classList.add("hidden");
            return;
        }
        text.innerText = queue.shift();
    }

    next();
    document.onkeydown = function(e){
        if(e.key === "Enter") next();
    };
}
