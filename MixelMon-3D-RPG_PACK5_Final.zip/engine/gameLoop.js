import {startWorld} from '../world/world.js';
import {startBattle} from '../battle/battle.js';

export function enterWorld(){
  document.body.style.background='black';
  startWorld();
}

export function enterBattle(){
  let flash=document.createElement('div');
  flash.style.position='fixed';
  flash.style.top=0;flash.style.left=0;
  flash.style.width='100%';flash.style.height='100%';
  flash.style.background='white';
  flash.style.opacity=1;
  flash.style.transition='opacity 0.4s';
  document.body.appendChild(flash);
  setTimeout(()=>{flash.style.opacity=0;},50);
  setTimeout(()=>{
    flash.remove();
    startBattle(1,2);
  },450);
}
