export let dragonsDB = [];

export async function loadDragonsDB(){
    if(dragonsDB.length > 0) return dragonsDB;
    let res = await fetch('./dragons/dragons.json');
    let data = await res.json();
    dragonsDB = data.dragons;
    return dragonsDB;
}
