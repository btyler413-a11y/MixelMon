export function createDragon(color=0xff0000){
    let group = new THREE.Group();

    let body = new THREE.Mesh(
        new THREE.BoxGeometry(2,1,4),
        new THREE.MeshStandardMaterial({color})
    );
    group.add(body);

    let head = new THREE.Mesh(
        new THREE.BoxGeometry(1.5,1.5,1.5),
        new THREE.MeshStandardMaterial({color: color+0x222222})
    );
    head.position.set(0,0.5,2.5);
    group.add(head);

    let wing1 = new THREE.Mesh(
        new THREE.BoxGeometry(0.4,2.5,3.5),
        new THREE.MeshStandardMaterial({color: color-0x111111})
    );
    wing1.position.set(1.5,0.5,0);
    wing1.rotation.z = -0.5;
    group.add(wing1);

    let wing2 = wing1.clone();
    wing2.position.set(-1.5,0.5,0);
    wing2.rotation.z = 0.5;
    group.add(wing2);

    group.tick = function(t){
        wing1.rotation.z = -0.5 + Math.sin(t*8)*0.1;
        wing2.rotation.z = 0.5 - Math.sin(t*8)*0.1;
    };

    return group;
}
