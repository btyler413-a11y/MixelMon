import { createDragon } from '../dragons/dragonModels.js';
import { loadDragonsDB } from '../dragons/dragons.js';

let scene, camera, renderer;
let playerDragon, enemyDragon;
let t = 0;

export function startBattle(teamDragon, wildDragon){
    loadDragonsDB().then(()=>{
        initBattleScene();
        spawnDragons(teamDragon, wildDragon);
        animate();
    });
}

function initBattleScene(){
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(65, window.innerWidth/window.innerHeight, 0.1, 200);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Black reflective mirror floor
    let floorGeo = new THREE.PlaneGeometry(200,200);
    let floorMat = new THREE.MeshStandardMaterial({
        color:0x000000,
        metalness:1,
        roughness:0
    });
    let floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI/2;
    scene.add(floor);

    let ambient = new THREE.AmbientLight(0x444444);
    scene.add(ambient);

    let rim = new THREE.DirectionalLight(0xffffff, 1.2);
    rim.position.set(0,20,10);
    scene.add(rim);

    camera.position.set(0, 10, 25);
}

function spawnDragons(teamDragon, enemyID){
    playerDragon = createDragon(0x3333ff);
    playerDragon.position.set(-6, 1, 0);
    scene.add(playerDragon);

    enemyDragon = createDragon(0xaa0000);
    enemyDragon.position.set(6, 1, 0);
    enemyDragon.rotation.y = Math.PI;
    scene.add(enemyDragon);
}

function animate(){
    requestAnimationFrame(animate);
    t += 0.01;
    if(playerDragon.tick) playerDragon.tick(t);
    if(enemyDragon.tick) enemyDragon.tick(t);
    renderer.render(scene, camera);
}
