export function checkCollisions(player){
    // Placeholder for wall/obstacle detection
}
