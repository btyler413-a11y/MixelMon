import { loadMap } from './mapLoader.js';
import { initPlayer, updatePlayer } from './playerController.js';
import { checkCollisions } from './collision.js';
import { overworldTransition } from './transitions.js';

let scene, camera, renderer, clock;

export function startWorld(){
    clock = new THREE.Clock();
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(70, window.innerWidth/window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    camera.position.set(0, 15, 15);
    camera.rotation.x = -0.6;

    loadMap("assets/maps/route1.json", scene);

    let player = initPlayer(scene);

    function loop(){
        requestAnimationFrame(loop);
        updatePlayer(player, scene);
        checkCollisions(player);
        overworldTransition(player);
        camera.position.x = player.position.x;
        camera.position.z = player.position.z + 10;
        renderer.render(scene, camera);
    }
    loop();
}
