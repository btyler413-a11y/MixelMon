import { keys } from '../engine/input.js';

export function initPlayer(scene){
    let mat = new THREE.MeshStandardMaterial({color:0x3333ff});
    let geo = new THREE.BoxGeometry(1,2,1);
    let player = new THREE.Mesh(geo, mat);
    player.position.set(0,2,0);
    scene.add(player);
    return player;
}

export function updatePlayer(p){
    if(keys['w']) p.position.z -= 0.15;
    if(keys['s']) p.position.z += 0.15;
    if(keys['a']) p.position.x -= 0.15;
    if(keys['d']) p.position.x += 0.15;
}
