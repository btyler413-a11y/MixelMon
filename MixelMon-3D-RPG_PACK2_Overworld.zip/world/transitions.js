export function overworldTransition(player){
    if(Math.random() < 0.001){
        console.log("Trigger battle transition");
        // Final version will switch to battle state
    }
}
