export function loadMap(path, scene){
    fetch(path).then(r=>r.json()).then(map=>{
        map.tiles.forEach(tile=>{
            let geo = new THREE.BoxGeometry(tile.w, tile.h, tile.d);
            let mat = new THREE.MeshStandardMaterial({color: tile.color});
            let cube = new THREE.Mesh(geo, mat);
            cube.position.set(tile.x, tile.y, tile.z);
            scene.add(cube);
        });
    });
}
