import { switchState } from './stateManager.js';
import './input.js';

window.startNewGame = function(){
    switchState("overworld");
};
window.loadSavedGame = function(){
    switchState("load");
};

console.log("Loader initialized");
