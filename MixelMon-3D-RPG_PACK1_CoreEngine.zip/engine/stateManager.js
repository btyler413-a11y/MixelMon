export let currentState = "menu";

export function switchState(state){
    console.log("Switching to state:", state);
    currentState = state;

    if(state === "overworld"){
        import('../world/world.js').then(m=>m.startWorld());
    }
    if(state === "load"){
        import('../save/saveSystem.js').then(m=>m.loadGame());
    }
}
