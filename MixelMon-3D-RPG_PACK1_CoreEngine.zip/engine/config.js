export const CONFIG = {
  version: "1.0",
  gameName: "MixelMon 3D RPG",
  debug: true
};